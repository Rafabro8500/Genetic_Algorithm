public interface IProblem {

    double fitness(Individual individual);
}
