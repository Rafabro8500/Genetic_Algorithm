import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class GeneticAlgorithm {
    public double CROSSOVER_PROBABILITY = 0.5;
    public double MUTATION_PROBABILITY = 0.05;
    public static IProblem problem = new OneMax();
    private Random rng = new Random(0);
    private Population population;
    private int tournamentSize;


    public GeneticAlgorithm(int populationSize, int chromosomeLength, int tournamentSize) {
        population = new Population(populationSize, chromosomeLength, rng);
        this.tournamentSize = tournamentSize;
    }

    public void nextGeneration() {
        population = population.tournamentWithoutReplacement(rng, tournamentSize);
        population = crossover(rng);
        population = mutation(rng);
    }

    private Population mutation(Random rng) {
        List<Individual> result = new ArrayList<>();
        for (Individual individual : population.getPopulation()) {
            result.add(individual.mutation(rng, MUTATION_PROBABILITY));
        }
        return new Population(result);
    }

    private Population crossover(Random rng) {// Single Point crossover between every 2 individuals in population with CROSSOVER_PROBABILITY
        List<Individual> result = new ArrayList<>();
        for (int i = 0; i < population.getPopulation().size() - 1; i += 2) {
            double r = rng.nextDouble();
            if (r < CROSSOVER_PROBABILITY) {
                List<Individual> children = population.getPopulation().get(i).singlePointCrossover(population.getPopulation().get(i + 1), rng);
                result.addAll(children);
            } else {
                result.add(population.getPopulation().get(i));
                result.add(population.getPopulation().get(i + 1));
            }
        }
        return new Population(result);
    }

    public Population getPopulation() {
        return population;
    }

}
